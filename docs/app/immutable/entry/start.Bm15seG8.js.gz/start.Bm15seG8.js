import{l as o,d as r}from"../chunks/CJboQ5uQ.js";export{o as load_css,r as start};
