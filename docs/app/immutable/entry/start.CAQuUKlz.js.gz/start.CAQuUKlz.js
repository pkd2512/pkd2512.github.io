import{d as a}from"../chunks/entry.BFb2zWKG.js";export{a as start};
