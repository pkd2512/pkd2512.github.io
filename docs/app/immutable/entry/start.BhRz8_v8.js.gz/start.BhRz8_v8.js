import{d as a}from"../chunks/entry.BVPnchl3.js";export{a as start};
