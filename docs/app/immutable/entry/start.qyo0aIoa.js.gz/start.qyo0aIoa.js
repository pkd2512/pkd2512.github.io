import{d as a}from"../chunks/entry.Dcl2Bnne.js";export{a as start};
