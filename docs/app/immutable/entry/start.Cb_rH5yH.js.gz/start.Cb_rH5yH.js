import{d as a}from"../chunks/entry.DBxHyVpE.js";export{a as start};
