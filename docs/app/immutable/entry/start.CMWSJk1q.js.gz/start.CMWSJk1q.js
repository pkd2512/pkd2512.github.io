import{d as a}from"../chunks/entry.8-7ugtjj.js";export{a as start};
