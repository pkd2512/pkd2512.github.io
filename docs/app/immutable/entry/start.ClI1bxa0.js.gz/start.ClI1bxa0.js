import{d as a}from"../chunks/entry.Drys3kDd.js";export{a as start};
