import{d as a}from"../chunks/entry.cxMcGdZD.js";export{a as start};
