import{d as a}from"../chunks/entry.BabVic2n.js";export{a as start};
