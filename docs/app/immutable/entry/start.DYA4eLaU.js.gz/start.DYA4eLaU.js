import{d as a}from"../chunks/entry.Obj0qnUD.js";export{a as start};
