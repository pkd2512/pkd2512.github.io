import{H as o}from"./control.c2cf8273.js";function n(r,e){return new o(r,e)}new TextEncoder;export{n as e};
