import{H as e}from"./entry.8-7ugtjj.js";function n(r,o){throw new e(r,o)}new TextEncoder;export{n as e};
