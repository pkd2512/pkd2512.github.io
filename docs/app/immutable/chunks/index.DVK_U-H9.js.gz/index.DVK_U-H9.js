import{H as e}from"./entry.Dcl2Bnne.js";function n(r,o){throw new e(r,o)}new TextEncoder;export{n as e};
