const o=typeof window!="undefined"?window:typeof globalThis!="undefined"?globalThis:global;export{o as g};
