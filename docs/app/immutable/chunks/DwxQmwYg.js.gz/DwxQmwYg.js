import{H as t}from"./D49y0osZ.js";function n(r,o){throw new t(r,o)}export{n as e};
