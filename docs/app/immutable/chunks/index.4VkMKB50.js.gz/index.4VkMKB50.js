import{H as e}from"./entry.DBxHyVpE.js";function n(r,o){throw new e(r,o)}new TextEncoder;export{n as e};
