import{n as a}from"./J8zXTXKB.js";a();
